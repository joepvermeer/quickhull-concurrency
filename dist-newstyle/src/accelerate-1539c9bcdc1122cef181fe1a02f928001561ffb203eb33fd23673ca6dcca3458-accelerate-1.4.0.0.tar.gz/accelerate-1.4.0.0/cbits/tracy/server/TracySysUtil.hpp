#ifndef __TRACYSYSUTIL_HPP__
#define __TRACYSYSUTIL_HPP__

#include <stdlib.h>

namespace tracy
{

size_t GetPhysicalMemorySize();

}

#endif
